from flask import Flask, render_template, request, redirect, url_for
from config import Config
from models import db, URL
import string, random
import validators

app = Flask(__name__)
app.config.from_object(Config)

db.init_app(app)

with app.app_context():
    db.create_all()

# Generate short code
def generate_short_code(length=6):
    characters = string.ascii_letters + string.digits
    return ''.join(random.choice(characters) for _ in range(length))

@app.route("/", methods=["GET", "POST"])
def home():
    short_url = None

    if request.method == "POST":
        original_url = request.form["url"]

        # URL validation
        if not validators.url(original_url):
            return render_template("index.html", error="Invalid URL")

        short_code = generate_short_code()

        new_url = URL(
            original_url=original_url,
            short_code=short_code
        )

        db.session.add(new_url)
        db.session.commit()

        short_url = request.host_url + short_code

    return render_template("index.html", short_url=short_url)

@app.route("/<short_code>")
def redirect_url(short_code):
    url_data = URL.query.filter_by(short_code=short_code).first()
    if url_data:
        return redirect(url_data.original_url)
    return "URL not found"

@app.route("/history")
def history():
    urls = URL.query.all()
    return render_template("history.html", urls=urls)

if __name__ == "__main__":
    app.run(debug=True)
