from flask import Flask, request

app = Flask(__name__)

@app.route("/")
def home():
    return """
    <h2>Welcome to Flask App</h2>
    <p>Use URL like:</p>
    <p><b>/transform?name=user_name</b></p>
    """



@app.route("/transform")
def transform():
    name = request.args.get("name", "")
    return {
        "original": name,
        "uppercase": name.upper(),
        "lowercase": name.lower(),
        "length": len(name),
        "reverse" : name[::-1]
    }


if __name__ == "__main__":
    app.run(debug=True)
